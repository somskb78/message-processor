# Project Title

Message Processor

## Getting Started

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes. 

### Prerequisites

Java 8 SDK

### Installing/Running

1. java -jar message-processor.jar.

## Running the tests

messages.txt  - contains set of messages that need to be processed.
log4j.xml - contains the logging information.

## Deployment

Extract message-processor.zip into a folder.
run the messasge-processor.jar
(refer to Installing section for more information)

## Built With

* [Maven](https://maven.apache.org/) - Dependency Management

## Versioning

1.0.0
